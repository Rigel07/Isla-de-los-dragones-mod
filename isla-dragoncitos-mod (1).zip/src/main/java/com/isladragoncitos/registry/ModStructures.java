package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.worldgen.IslaPiece;
import com.isladragoncitos.worldgen.IslaStructure;
import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModStructures {
    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
            DeferredRegister.create(Registries.STRUCTURE_TYPE, IslaDragoncitosMod.MODID);
    public static final DeferredRegister<StructurePieceType> STRUCTURE_PIECES =
            DeferredRegister.create(Registries.STRUCTURE_PIECE, IslaDragoncitosMod.MODID);

    public static final RegistryObject<StructureType<IslaStructure>> ISLA_TYPE =
            STRUCTURE_TYPES.register("isla", () -> typeOf(IslaStructure.CODEC));

    public static final RegistryObject<StructurePieceType> ISLA_PIECE =
            STRUCTURE_PIECES.register("isla_piece", () -> (StructurePieceType.ContextlessType) IslaPiece::new);

    private ModStructures() {}

    private static <S extends Structure> StructureType<S> typeOf(Codec<S> codec) {
        return () -> codec;
    }
}
