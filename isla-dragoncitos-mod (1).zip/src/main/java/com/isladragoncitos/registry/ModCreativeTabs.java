package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, IslaDragoncitosMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("isla_dragoncitos",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.isladragoncitos"))
                    .icon(() -> new ItemStack(ModItems.PINK_DRAGON_SCALE.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.DRAGONCITO_SPAWN_EGG.get());
                        output.accept(ModItems.PINK_DRAGON_SCALE.get());
                        output.accept(ModItems.GREEN_DRAGON_SCALE.get());
                        output.accept(ModItems.BLUE_DRAGON_SCALE.get());
                        output.accept(ModItems.RED_DRAGON_SCALE.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
