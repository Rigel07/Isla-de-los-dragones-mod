package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, IslaDragoncitosMod.MODID);

    public static final RegistryObject<Item> PINK_DRAGON_SCALE = scale("pink_dragon_scale");
    public static final RegistryObject<Item> GREEN_DRAGON_SCALE = scale("green_dragon_scale");
    public static final RegistryObject<Item> BLUE_DRAGON_SCALE = scale("blue_dragon_scale");
    public static final RegistryObject<Item> RED_DRAGON_SCALE = scale("red_dragon_scale");

    public static final RegistryObject<Item> DRAGONCITO_SPAWN_EGG = ITEMS.register("dragoncito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.DRAGONCITO, 0xFF8FBF, 0x66CCFF, new Item.Properties()));

    public static final RegistryObject<Item> DRAGON_STATUE = ITEMS.register("dragon_statue",
            () -> new BlockItem(ModBlocks.DRAGON_STATUE.get(), new Item.Properties().rarity(Rarity.EPIC)));

    private ModItems() {}

    private static RegistryObject<Item> scale(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(Rarity.RARE)));
    }
}
