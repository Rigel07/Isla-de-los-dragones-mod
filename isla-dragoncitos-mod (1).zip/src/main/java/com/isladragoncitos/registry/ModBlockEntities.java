package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.IslandStatueBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, IslaDragoncitosMod.MODID);

    public static final RegistryObject<BlockEntityType<IslandStatueBlockEntity>> STATUE = BLOCK_ENTITIES.register("dragon_statue",
            () -> BlockEntityType.Builder.of(IslandStatueBlockEntity::new, ModBlocks.DRAGON_STATUE.get()).build(null));

    private ModBlockEntities() {}
}
