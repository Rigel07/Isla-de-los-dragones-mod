package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.IslandStatueBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, IslaDragoncitosMod.MODID);

    /** Estatua de teletransporte: indestructible, brilla suavemente. */
    public static final RegistryObject<Block> DRAGON_STATUE = BLOCKS.register("dragon_statue",
            () -> new IslandStatueBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 8)
                    .noOcclusion()
                    .pushReaction(PushReaction.BLOCK)));

    private ModBlocks() {}
}
