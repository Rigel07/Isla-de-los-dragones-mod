package com.isladragoncitos.entity;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.DRAGONCITO.get(), DragoncitoEntity.createAttributes().build());
    }
}
