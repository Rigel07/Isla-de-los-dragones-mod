package com.isladragoncitos.worldgen;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Geometria de una isla, siempre en coordenadas RELATIVAS al centro (x, z).
 * Es una funcion pura de (semilla, radio, angulo de la cascada): cada chunk puede
 * generar su parte de la isla de forma independiente y el resultado encaja.
 */
public final class IslaShape {
    public static final int SHRINE_HALF = 3;
    public static final double PLAZA_RADIUS = 5.0D;
    public static final double PILLAR_RADIUS = 7.0D;

    public final long seed;
    public final int radius;
    public final int depth;
    public final double fallAngle;

    private final double p1;
    private final double p2;
    private final double p3;

    // lago
    private final double lakeX;
    private final double lakeZ;
    private final double lakeA;
    private final double lakeB;
    private final double axisCos;
    private final double axisSin;

    // canal del lago al borde + cascada
    public final List<int[]> channel = new ArrayList<>();
    private final Set<Long> channelSet = new HashSet<>();
    public int lipX;
    public int lipZ;
    public int fallX;
    public int fallZ;

    // enredadera
    public final double vineAngle;
    public int vineX;
    public int vineZ;
    public int vineSx;
    public int vineSz;
    public final double vinePhaseX;
    public final double vinePhaseZ;

    // santuario
    public final double shrineAngle;
    public int shrineX;
    public int shrineZ;
    public int doorX;
    public int doorZ;

    // pilares
    public final int[][] pillars = new int[8][2];
    public final int[] pillarHeight = new int[8];
    public final boolean[] arch = new boolean[8];

    // puntos de aparicion de dragoncitos
    public final List<int[]> spawns = new ArrayList<>();

    public IslaShape(long seed, int radius, double fallAngle) {
        this.seed = seed;
        this.radius = radius;
        this.fallAngle = fallAngle;
        this.depth = radius - 6;

        Random r = new Random(seed);
        this.p1 = r.nextDouble() * Math.PI * 2.0D;
        this.p2 = r.nextDouble() * Math.PI * 2.0D;
        this.p3 = r.nextDouble() * Math.PI * 2.0D;
        this.vineAngle = fallAngle + Math.PI + (r.nextDouble() - 0.5D) * 0.9D;
        this.shrineAngle = fallAngle + (r.nextBoolean() ? 1.0D : -1.0D) * (Math.PI / 2.0D)
                + (r.nextDouble() - 0.5D) * 0.5D;
        this.vinePhaseX = r.nextDouble() * Math.PI * 2.0D;
        this.vinePhaseZ = r.nextDouble() * Math.PI * 2.0D;

        this.axisCos = Math.cos(fallAngle);
        this.axisSin = Math.sin(fallAngle);
        double lakeDist = radius * 0.62D;
        this.lakeX = axisCos * lakeDist;
        this.lakeZ = axisSin * lakeDist;
        this.lakeA = 5.0D;
        this.lakeB = 4.4D;

        computeChannel(lakeDist);
        computeVine();
        computeShrine();
        computePillars(r);
        computeSpawns(r);
    }

    // ------------------------------------------------------------------ forma

    public double radiusAt(double theta) {
        return radius * (1.0D + 0.06D * Math.sin(3.0D * theta + p1)
                + 0.04D * Math.sin(5.0D * theta + p2)
                + 0.025D * Math.sin(7.0D * theta + p3));
    }

    public boolean inside(int x, int z) {
        double d = Math.sqrt((double) x * x + (double) z * z);
        if (d < 1.0E-6D) {
            return true;
        }
        return d <= radiusAt(Math.atan2(z, x));
    }

    /** Distancia al centro dividida por el radio local: 0 en el centro, 1 en el borde. */
    public double frac(int x, int z) {
        double d = Math.sqrt((double) x * x + (double) z * z);
        if (d < 1.0E-6D) {
            return 0.0D;
        }
        return d / radiusAt(Math.atan2(z, x));
    }

    public boolean nearLake(int x, int z, double scale) {
        double dx = x - lakeX;
        double dz = z - lakeZ;
        double u = dx * axisCos + dz * axisSin;
        double v = -dx * axisSin + dz * axisCos;
        double wobble = 1.0D + 0.12D * Math.sin(3.0D * Math.atan2(v, u) + p1);
        double e = (u / lakeA) * (u / lakeA) + (v / lakeB) * (v / lakeB);
        double limit = scale * wobble;
        return e <= limit * limit;
    }

    public boolean isChannel(int x, int z) {
        return channelSet.contains(key(x, z));
    }

    public boolean nearChannel(int x, int z) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (channelSet.contains(key(x + i, z + j))) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean inPlaza(int x, int z) {
        return (double) (x * x + z * z) <= PLAZA_RADIUS * PLAZA_RADIUS;
    }

    public boolean inShrine(int x, int z, int margin) {
        return Math.abs(x - shrineX) <= SHRINE_HALF + margin && Math.abs(z - shrineZ) <= SHRINE_HALF + margin;
    }

    /** Zonas que se mantienen planas y sin vegetacion aleatoria. */
    public boolean isReserved(int x, int z) {
        return x * x + z * z <= 100 || nearLake(x, z, 1.45D) || nearChannel(x, z) || inShrine(x, z, 3);
    }

    /** Desplazamiento (relativo a la superficie base) de la capa superior. */
    public int topOffset(int x, int z) {
        if (isReserved(x, z)) {
            return 0;
        }
        double d = Math.sqrt((double) x * x + (double) z * z);
        double f = frac(x, z);
        double amp = clamp((d - 10.0D) / 6.0D, 0.0D, 1.0D) * (1.0D - clamp((f - 0.8D) / 0.2D, 0.0D, 1.0D)) * 1.8D;
        double n = Math.sin(x * 0.23D + p1) * Math.cos(z * 0.19D + p2) + 0.5D * Math.sin(x * 0.11D - z * 0.13D + p3);
        return Math.max(-1, (int) Math.round(amp * n));
    }

    /** Desplazamiento (negativo) de la base inferior: la isla es una lente gruesa en el centro. */
    public int bottomOffset(int x, int z) {
        double f = Math.min(1.0D, frac(x, z));
        double t = Math.pow(Math.max(0.0D, 1.0D - f * f), 0.85D);
        double n = 1.6D * Math.sin(x * 0.45D + p2) * Math.sin(z * 0.4D + p3) * (1.0D - f);
        return -2 - (int) Math.round(depth * t + n);
    }

    public double rnd(int a, int b, int c) {
        long h = seed ^ ((long) a * 0x9E3779B97F4A7C15L) ^ ((long) b * 0xC2B2AE3D27D4EB4FL) ^ ((long) c * 0x165667B19E3779F9L);
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return (h >>> 11) * (1.0D / (double) (1L << 53));
    }

    // ------------------------------------------------------------ construccion

    private void computeChannel(double lakeDist) {
        List<int[]> cells = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        int[] lastInside = null;
        int[] firstOutside = null;
        for (double t = lakeDist; t < radius * 1.8D; t += 0.3D) {
            int x = (int) Math.round(axisCos * t);
            int z = (int) Math.round(axisSin * t);
            if (!seen.add(key(x, z))) {
                continue;
            }
            if (inside(x, z)) {
                cells.add(new int[]{x, z});
                lastInside = new int[]{x, z};
            } else {
                firstOutside = new int[]{x, z};
                break;
            }
        }
        if (lastInside == null || firstOutside == null) {
            lastInside = new int[]{(int) Math.round(axisCos * radius * 0.8D), (int) Math.round(axisSin * radius * 0.8D)};
            firstOutside = new int[]{lastInside[0] + 2, lastInside[1]};
        }

        // la columna de agua debe quedar pegada (ortogonalmente) al ultimo bloque de agua del canal
        int[] lip = lastInside;
        int[] out = firstOutside;
        if (Math.abs(out[0] - lip[0]) + Math.abs(out[1] - lip[1]) != 1) {
            int[] c1 = {out[0], lip[1]};
            int[] c2 = {lip[0], out[1]};
            if (!inside(c1[0], c1[1])) {
                out = c1;
            } else if (!inside(c2[0], c2[1])) {
                out = c2;
            } else {
                cells.add(c1);
                lip = c1;
            }
        }
        for (int[] cell : cells) {
            channel.add(cell);
            channelSet.add(key(cell[0], cell[1]));
        }
        lipX = lip[0];
        lipZ = lip[1];
        fallX = out[0];
        fallZ = out[1];
    }

    private void computeVine() {
        double c = Math.cos(vineAngle);
        double s = Math.sin(vineAngle);
        int[] out = null;
        for (double t = radius * 0.6D; t < radius * 1.8D; t += 0.25D) {
            int x = (int) Math.round(c * t);
            int z = (int) Math.round(s * t);
            if (!inside(x, z)) {
                out = new int[]{x, z};
                break;
            }
        }
        if (out == null) {
            out = new int[]{(int) Math.round(c * radius * 1.2D), (int) Math.round(s * radius * 1.2D)};
        }
        vineX = out[0];
        vineZ = out[1];
        vineSx = c >= 0.0D ? 1 : -1;
        vineSz = s >= 0.0D ? 1 : -1;
    }

    private void computeShrine() {
        int bestX = 0;
        int bestZ = 0;
        boolean found = false;
        for (double f = 0.62D; f >= 0.40D && !found; f -= 0.03D) {
            int sx = (int) Math.round(Math.cos(shrineAngle) * radius * f);
            int sz = (int) Math.round(Math.sin(shrineAngle) * radius * f);
            boolean fits = true;
            for (int dx = -(SHRINE_HALF + 1); dx <= SHRINE_HALF + 1 && fits; dx += SHRINE_HALF + 1) {
                for (int dz = -(SHRINE_HALF + 1); dz <= SHRINE_HALF + 1; dz += SHRINE_HALF + 1) {
                    if (frac(sx + dx, sz + dz) > 0.86D || nearLake(sx + dx, sz + dz, 1.6D)) {
                        fits = false;
                        break;
                    }
                }
            }
            if (fits && Math.sqrt((double) sx * sx + (double) sz * sz) >= 11.0D) {
                bestX = sx;
                bestZ = sz;
                found = true;
            }
        }
        if (!found) {
            bestX = (int) Math.round(Math.cos(shrineAngle) * radius * 0.5D);
            bestZ = (int) Math.round(Math.sin(shrineAngle) * radius * 0.5D);
        }
        shrineX = bestX;
        shrineZ = bestZ;
        if (Math.abs(shrineX) >= Math.abs(shrineZ)) {
            doorX = shrineX > 0 ? -1 : 1;
            doorZ = 0;
        } else {
            doorX = 0;
            doorZ = shrineZ > 0 ? -1 : 1;
        }
    }

    private void computePillars(Random r) {
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0D + Math.PI / 8.0D;
            int x = (int) Math.round(Math.cos(a) * PILLAR_RADIUS);
            int z = (int) Math.round(Math.sin(a) * PILLAR_RADIUS);
            pillars[i][0] = x;
            pillars[i][1] = z;
            int h = 3 + r.nextInt(5);
            if (r.nextInt(100) < 30) {
                h = 1 + r.nextInt(3);
            }
            arch[i] = r.nextInt(100) < 65;
            if (inShrine(x, z, 2) || nearLake(x, z, 1.5D) || nearChannel(x, z)) {
                h = 0;
            }
            pillarHeight[i] = h;
        }
    }

    private void computeSpawns(Random r) {
        for (int attempt = 0; attempt < 300 && spawns.size() < 14; attempt++) {
            double a = r.nextDouble() * Math.PI * 2.0D;
            double rr = 3.0D + r.nextDouble() * (radius * 0.82D - 3.0D);
            int x = (int) Math.round(Math.cos(a) * rr);
            int z = (int) Math.round(Math.sin(a) * rr);
            if (!inside(x, z) || nearLake(x, z, 1.35D) || inShrine(x, z, 2) || nearChannel(x, z)) {
                continue;
            }
            spawns.add(new int[]{x, z});
        }
    }

    private static long key(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
