package com.isladragoncitos.worldgen;

import com.isladragoncitos.block.IslandStatueBlock;
import com.isladragoncitos.block.IslandStatueBlockEntity;
import com.isladragoncitos.entity.DragoncitoEntity;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.material.Fluids;

/** La isla flotante completa. Cada chunk coloca su parte a partir de la geometria determinista de IslaShape. */
public class IslaPiece extends StructurePiece {
    private static final ResourceLocation CHEST_LOOT = new ResourceLocation("isladragoncitos", "chests/isla_cofre");

    private static final BlockState GRASS_BLOCK = Blocks.GRASS_BLOCK.defaultBlockState();
    private static final BlockState PODZOL = Blocks.PODZOL.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState COARSE_DIRT = Blocks.COARSE_DIRT.defaultBlockState();
    private static final BlockState SAND = Blocks.SAND.defaultBlockState();
    private static final BlockState CLAY = Blocks.CLAY.defaultBlockState();
    private static final BlockState GRAVEL = Blocks.GRAVEL.defaultBlockState();
    private static final BlockState STONE = Blocks.STONE.defaultBlockState();
    private static final BlockState ANDESITE = Blocks.ANDESITE.defaultBlockState();
    private static final BlockState TUFF = Blocks.TUFF.defaultBlockState();
    private static final BlockState MOSSY_COBBLE = Blocks.MOSSY_COBBLESTONE.defaultBlockState();
    private static final BlockState CALCITE = Blocks.CALCITE.defaultBlockState();
    private static final BlockState STONE_BRICKS = Blocks.STONE_BRICKS.defaultBlockState();
    private static final BlockState MOSSY_BRICKS = Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
    private static final BlockState CRACKED_BRICKS = Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
    private static final BlockState CHISELED = Blocks.CHISELED_STONE_BRICKS.defaultBlockState();
    private static final BlockState BRICK_SLAB = Blocks.STONE_BRICK_SLAB.defaultBlockState();
    private static final BlockState AMETHYST = Blocks.AMETHYST_BLOCK.defaultBlockState();
    private static final BlockState POLISHED_ANDESITE = Blocks.POLISHED_ANDESITE.defaultBlockState();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState WATER = Blocks.WATER.defaultBlockState();
    private static final BlockState FLOW_TOP = Blocks.WATER.defaultBlockState().setValue(BlockStateProperties.LEVEL, 1);
    private static final BlockState FALLING_WATER = Blocks.WATER.defaultBlockState().setValue(BlockStateProperties.LEVEL, 8);
    private static final BlockState PINK_CARPET = Blocks.PINK_CARPET.defaultBlockState();
    private static final BlockState MOSS_CARPET = Blocks.MOSS_CARPET.defaultBlockState();
    private static final BlockState LANTERN = Blocks.LANTERN.defaultBlockState();
    private static final BlockState BOOKSHELF = Blocks.BOOKSHELF.defaultBlockState();
    private static final BlockState MOSS_BLOCK = Blocks.MOSS_BLOCK.defaultBlockState();
    private static final BlockState MANGROVE_ROOTS = Blocks.MANGROVE_ROOTS.defaultBlockState();
    private static final BlockState MUDDY_ROOTS = Blocks.MUDDY_MANGROVE_ROOTS.defaultBlockState();
    private static final BlockState GRASS = Blocks.GRASS.defaultBlockState();
    private static final BlockState FERN = Blocks.FERN.defaultBlockState();
    private static final BlockState[] FLOWERS = {
            Blocks.DANDELION.defaultBlockState(), Blocks.POPPY.defaultBlockState(),
            Blocks.AZURE_BLUET.defaultBlockState(), Blocks.OXEYE_DAISY.defaultBlockState(),
            Blocks.CORNFLOWER.defaultBlockState(), Blocks.PINK_TULIP.defaultBlockState(),
            Blocks.ALLIUM.defaultBlockState(), Blocks.LILY_OF_THE_VALLEY.defaultBlockState()
    };

    private IslaShape shape;
    private int cx;
    private int cz;
    private int top;
    private int radius;
    private long seed;
    private double fallAngle;
    private int groundVine;
    private int groundFall;
    private boolean overWater;

    private int trunkBase;
    private int[] trunkAx;
    private int[] trunkAz;

    public IslaPiece(int cx, int cz, int top, int radius, long seed, double fallAngle,
                     int groundVine, int groundFall, boolean overWater) {
        this(new IslaShape(seed, radius, fallAngle), cx, cz, top, radius, seed, fallAngle, groundVine, groundFall, overWater);
    }

    private IslaPiece(IslaShape shape, int cx, int cz, int top, int radius, long seed, double fallAngle,
                      int groundVine, int groundFall, boolean overWater) {
        super(ModStructures.ISLA_PIECE.get(), 0, computeBox(cx, cz, top, radius, groundVine, groundFall));
        this.shape = shape;
        this.cx = cx;
        this.cz = cz;
        this.top = top;
        this.radius = radius;
        this.seed = seed;
        this.fallAngle = fallAngle;
        this.groundVine = groundVine;
        this.groundFall = groundFall;
        this.overWater = overWater;
        initTrunk();
    }

    public IslaPiece(CompoundTag tag) {
        super(ModStructures.ISLA_PIECE.get(), tag);
        this.cx = tag.getInt("Cx");
        this.cz = tag.getInt("Cz");
        this.top = tag.getInt("Top");
        this.radius = tag.getInt("Radius");
        this.seed = tag.getLong("Seed");
        this.fallAngle = tag.getDouble("FallAngle");
        this.groundVine = tag.getInt("GroundVine");
        this.groundFall = tag.getInt("GroundFall");
        this.overWater = tag.getBoolean("OverWater");
        this.shape = new IslaShape(seed, radius, fallAngle);
        initTrunk();
    }

    private static BoundingBox computeBox(int cx, int cz, int top, int radius, int groundVine, int groundFall) {
        int m = radius + 12;
        return new BoundingBox(cx - m, Math.min(groundVine, groundFall) - 4, cz - m,
                cx + m, top + 16, cz + m);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Cx", cx);
        tag.putInt("Cz", cz);
        tag.putInt("Top", top);
        tag.putInt("Radius", radius);
        tag.putLong("Seed", seed);
        tag.putDouble("FallAngle", fallAngle);
        tag.putInt("GroundVine", groundVine);
        tag.putInt("GroundFall", groundFall);
        tag.putBoolean("OverWater", overWater);
    }

    // ------------------------------------------------------------------ helpers

    private void initTrunk() {
        trunkBase = groundVine - 2;
        int len = top + 2 - trunkBase + 1;
        trunkAx = new int[len];
        trunkAz = new int[len];
        for (int i = 0; i < len; i++) {
            int y = trunkBase + i;
            double f = (double) (y - groundVine) / Math.max(1, top - groundVine);
            f = Math.max(0.0D, Math.min(1.0D, f));
            double amp = 2.0D * (1.0D - f);
            trunkAx[i] = shape.vineX + (int) Math.round(amp * Math.sin(y * 0.16D + shape.vinePhaseX));
            trunkAz[i] = shape.vineZ + (int) Math.round(amp * Math.cos(y * 0.13D + shape.vinePhaseZ));
        }
    }

    private boolean isTrunk(int rx, int y, int rz) {
        int i = y - trunkBase;
        if (i < 0 || i >= trunkAx.length || y > top + 1) {
            return false;
        }
        int ax = trunkAx[i];
        int az = trunkAz[i];
        return (rx == ax || rx == ax + shape.vineSx) && (rz == az || rz == az + shape.vineSz);
    }

    private static void put(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        if (box.isInside(x, y, z)) {
            level.setBlock(new BlockPos(x, y, z), state, 2);
        }
    }

    private static boolean isAirAt(WorldGenLevel level, BoundingBox box, int x, int y, int z) {
        return box.isInside(x, y, z) && level.getBlockState(new BlockPos(x, y, z)).isAir();
    }

    private static void putIfAir(WorldGenLevel level, BoundingBox box, int x, int y, int z, BlockState state) {
        if (isAirAt(level, box, x, y, z)) {
            level.setBlock(new BlockPos(x, y, z), state, 2);
        }
    }

    private static BlockState leaves(BlockState base) {
        return base.setValue(LeavesBlock.PERSISTENT, true);
    }

    private BlockState brickMix(int a, int b, int c) {
        double r = shape.rnd(a, b, c);
        if (r < 0.58D) {
            return STONE_BRICKS;
        }
        if (r < 0.84D) {
            return MOSSY_BRICKS;
        }
        return CRACKED_BRICKS;
    }

    // --------------------------------------------------------------- generacion

    @Override
    public void postProcess(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator,
                            RandomSource random, BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        int r = shape.radius;
        int ix0 = Math.max(box.minX(), cx - r - 3);
        int ix1 = Math.min(box.maxX(), cx + r + 3);
        int iz0 = Math.max(box.minZ(), cz - r - 3);
        int iz1 = Math.min(box.maxZ(), cz + r + 3);

        if (ix0 <= ix1 && iz0 <= iz1) {
            placeBody(level, box, ix0, ix1, iz0, iz1);
            placeLakeAndChannel(level, box, ix0, ix1, iz0, iz1);
            placePlaza(level, box, ix0, ix1, iz0, iz1);
            placeFlora(level, box, ix0, ix1, iz0, iz1);
            placeUndersideVines(level, box, ix0, ix1, iz0, iz1);
        }
        placeShrine(level, box, random);
        placePillars(level, box);
        placeCenterpiece(level, box, random);
        placeTrees(level, box);
        placeVine(level, box);
        placeWaterfall(level, box);
        spawnDragons(level, box);
    }

    private void placeBody(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz)) {
                    continue;
                }
                int topY = top + shape.topOffset(rx, rz);
                int botY = top + shape.bottomOffset(rx, rz);
                boolean beach = shape.nearLake(rx, rz, 1.4D);
                for (int y = botY; y <= topY; y++) {
                    put(level, box, x, y, z, bodyBlock(rx, rz, y, topY, botY, beach));
                }
            }
        }
    }

    private BlockState bodyBlock(int rx, int rz, int y, int topY, int botY, boolean beach) {
        double r = shape.rnd(rx, y, rz);
        if (y == topY) {
            if (beach) {
                return SAND;
            }
            return r < 0.06D ? PODZOL : GRASS_BLOCK;
        }
        int dy = topY - y;
        if (dy <= 3) {
            if (beach && dy <= 2) {
                return SAND;
            }
            return r < 0.12D ? COARSE_DIRT : DIRT;
        }
        if (y <= botY + 1) {
            if (r < 0.45D) {
                return STONE;
            }
            if (r < 0.65D) {
                return ANDESITE;
            }
            if (r < 0.82D) {
                return TUFF;
            }
            if (r < 0.94D) {
                return MOSSY_COBBLE;
            }
            return CALCITE;
        }
        if (r < 0.10D) {
            return ANDESITE;
        }
        if (r < 0.16D) {
            return TUFF;
        }
        return STONE;
    }

    private void placeLakeAndChannel(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz) || !shape.nearLake(rx, rz, 1.0D)) {
                    continue;
                }
                double r = shape.rnd(rx, 3, rz);
                put(level, box, x, top - 4, z, r < 0.5D ? SAND : (r < 0.8D ? CLAY : GRAVEL));
                for (int y = top - 3; y <= top - 1; y++) {
                    put(level, box, x, y, z, WATER);
                }
                for (int y = top; y <= top + 4; y++) {
                    put(level, box, x, y, z, AIR);
                }
            }
        }
        for (int[] cell : shape.channel) {
            int x = cx + cell[0];
            int z = cz + cell[1];
            put(level, box, x, top - 1, z, WATER);
            for (int y = top; y <= top + 4; y++) {
                put(level, box, x, y, z, AIR);
            }
        }
        int lx = cx + shape.lipX;
        int lz = cz + shape.lipZ;
        if (box.isInside(lx, top - 1, lz)) {
            level.scheduleTick(new BlockPos(lx, top - 1, lz), Fluids.WATER, 0);
        }
    }

    private BlockState plazaBlock(int rx, int rz) {
        double d = Math.sqrt((double) rx * rx + (double) rz * rz);
        double r = shape.rnd(rx, 9, rz);
        if (d <= 1.6D) {
            return CHISELED;
        }
        if (d >= 2.6D && d <= 3.4D) {
            return r < 0.8D ? AMETHYST : STONE_BRICKS;
        }
        if (r < 0.6D) {
            return STONE_BRICKS;
        }
        if (r < 0.82D) {
            return MOSSY_BRICKS;
        }
        if (r < 0.92D) {
            return CRACKED_BRICKS;
        }
        return MOSSY_COBBLE;
    }

    private void placePlaza(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (shape.inPlaza(rx, rz)) {
                    put(level, box, x, top, z, plazaBlock(rx, rz));
                }
            }
        }
    }

    private void placeFlora(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz) || rx * rx + rz * rz <= 36 || shape.nearLake(rx, rz, 1.45D)
                        || shape.nearChannel(rx, rz) || shape.inShrine(rx, rz, 1)) {
                    continue;
                }
                int ty = top + shape.topOffset(rx, rz);
                if (!box.isInside(x, ty, z) || !box.isInside(x, ty + 1, z)) {
                    continue;
                }
                if (!level.getBlockState(new BlockPos(x, ty, z)).is(Blocks.GRASS_BLOCK)
                        || !level.getBlockState(new BlockPos(x, ty + 1, z)).isAir()) {
                    continue;
                }
                double r = shape.rnd(rx, 11, rz);
                BlockState state = null;
                if (r < 0.26D) {
                    state = GRASS;
                } else if (r < 0.31D) {
                    state = FERN;
                } else if (r < 0.40D) {
                    state = FLOWERS[(int) (shape.rnd(rx, 12, rz) * FLOWERS.length) % FLOWERS.length];
                } else if (r < 0.45D) {
                    state = Blocks.PINK_PETALS.defaultBlockState()
                            .setValue(BlockStateProperties.FLOWER_AMOUNT, 1 + (int) (shape.rnd(rx, 13, rz) * 4.0D));
                } else if (r < 0.455D) {
                    state = Blocks.FLOWERING_AZALEA.defaultBlockState();
                }
                if (state != null) {
                    put(level, box, x, ty + 1, z, state);
                }
            }
        }
    }

    private void hangVines(WorldGenLevel level, BoundingBox box, int x, int startY, int z, int length, double berries) {
        for (int k = 0; k < length; k++) {
            int y = startY - k;
            if (!isAirAt(level, box, x, y, z)) {
                break;
            }
            boolean hasBerries = shape.rnd(x, y, z + 77) < berries;
            BlockState state = (k == length - 1 ? Blocks.CAVE_VINES : Blocks.CAVE_VINES_PLANT).defaultBlockState()
                    .setValue(BlockStateProperties.BERRIES, hasBerries);
            put(level, box, x, y, z, state);
        }
    }

    private void placeUndersideVines(WorldGenLevel level, BoundingBox box, int ix0, int ix1, int iz0, int iz1) {
        for (int x = ix0; x <= ix1; x++) {
            for (int z = iz0; z <= iz1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                if (!shape.inside(rx, rz)) {
                    continue;
                }
                double f = shape.frac(rx, rz);
                if (f < 0.3D || f > 0.96D || shape.rnd(rx, 91, rz) >= 0.07D) {
                    continue;
                }
                int botY = top + shape.bottomOffset(rx, rz);
                int length = 2 + (int) (shape.rnd(rx, 92, rz) * 6.0D);
                hangVines(level, box, x, botY - 1, z, length, 0.35D);
            }
        }
    }

    // --------------------------------------------------------- santuario y pilares

    private void placeShrine(WorldGenLevel level, BoundingBox box, RandomSource random) {
        int sx = cx + shape.shrineX;
        int sz = cz + shape.shrineZ;
        int half = IslaShape.SHRINE_HALF;
        Direction doorDir = Direction.fromNormal(shape.doorX, 0, shape.doorZ);
        if (doorDir == null) {
            doorDir = Direction.NORTH;
        }
        BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, doorDir);

        for (int x = sx - half; x <= sx + half; x++) {
            for (int z = sz - half; z <= sz + half; z++) {
                if (x < box.minX() || x > box.maxX() || z < box.minZ() || z > box.maxZ()) {
                    continue;
                }
                int ox = x - sx;
                int oz = z - sz;
                boolean edge = Math.abs(ox) == half || Math.abs(oz) == half;
                int along = ox * shape.doorX + oz * shape.doorZ;
                int perp = shape.doorX != 0 ? oz : ox;

                double fr = shape.rnd(ox, 20, oz);
                put(level, box, x, top, z, fr < 0.55D ? STONE_BRICKS : (fr < 0.8D ? MOSSY_BRICKS
                        : (fr < 0.92D ? CRACKED_BRICKS : POLISHED_ANDESITE)));

                if (edge) {
                    boolean corner = Math.abs(ox) == half && Math.abs(oz) == half;
                    boolean middle = ox == 0 || oz == 0;
                    for (int k = 1; k <= 4; k++) {
                        boolean door = along == half && perp == 0 && k <= 2;
                        boolean window = middle && along != half && k >= 2 && k <= 3;
                        if (door || window) {
                            put(level, box, x, top + k, z, AIR);
                            continue;
                        }
                        double r = shape.rnd(ox, 21 + k, oz);
                        if (!corner && k >= 3 && r < 0.18D) {
                            continue;
                        }
                        if (k == 4 && r < 0.45D) {
                            continue;
                        }
                        put(level, box, x, top + k, z, corner && k == 1 ? CHISELED : brickMix(ox, 30 + k, oz));
                    }
                    double roofR = shape.rnd(ox, 40, oz);
                    if (roofR >= 0.1D) {
                        put(level, box, x, top + 5, z, STONE_BRICKS);
                    }
                } else {
                    for (int k = 1; k <= 4; k++) {
                        put(level, box, x, top + k, z, AIR);
                    }
                    if (shape.rnd(ox, 41, oz) < 0.65D) {
                        put(level, box, x, top + 5, z, BRICK_SLAB);
                    }
                    boolean back = along == -2;
                    if (back && perp == 0) {
                        put(level, box, x, top + 1, z, BOOKSHELF);
                        put(level, box, x, top + 2, z, BOOKSHELF);
                    } else if (back && Math.abs(perp) == 2) {
                        BlockPos chestPos = new BlockPos(x, top + 1, z);
                        createChest(level, box, random, chestPos, CHEST_LOOT, chest);
                    } else if (along == 2 && Math.abs(perp) == 2) {
                        put(level, box, x, top + 1, z, LANTERN);
                    } else if (perp == 0) {
                        put(level, box, x, top + 1, z, PINK_CARPET);
                    } else if (shape.rnd(ox, 42, oz) < 0.15D) {
                        put(level, box, x, top + 1, z, MOSS_CARPET);
                    }
                }
            }
        }
    }

    private void placePillars(WorldGenLevel level, BoundingBox box) {
        for (int i = 0; i < 8; i++) {
            int h = shape.pillarHeight[i];
            if (h <= 0) {
                continue;
            }
            int px = cx + shape.pillars[i][0];
            int pz = cz + shape.pillars[i][1];
            for (int k = 1; k <= h; k++) {
                BlockState state;
                if (k == 1 || (k == h && shape.rnd(i, 50, k) < 0.5D)) {
                    state = CHISELED;
                } else {
                    state = brickMix(i, 51, k);
                }
                put(level, box, px, top + k, pz, state);
            }
        }

        for (int i = 0; i < 8; i++) {
            int j = (i + 1) % 8;
            int hi = shape.pillarHeight[i];
            int hj = shape.pillarHeight[j];
            if (!shape.arch[i] || hi < 5 || hj < 5) {
                continue;
            }
            int ax = shape.pillars[i][0];
            int az = shape.pillars[i][1];
            int bx = shape.pillars[j][0];
            int bz = shape.pillars[j][1];
            int steps = Math.max(Math.abs(bx - ax), Math.abs(bz - az));
            int y = top + Math.min(hi, hj) + 1;
            for (int s = 1; s < steps; s++) {
                double t = (double) s / steps;
                int lx = (int) Math.round(ax + (bx - ax) * t);
                int lz = (int) Math.round(az + (bz - az) * t);
                if (shape.rnd(lx, 52, lz) < 0.12D) {
                    continue;
                }
                put(level, box, cx + lx, y, cz + lz, brickMix(lx, 53, lz));
                if (shape.rnd(lx, 54, lz) < 0.45D) {
                    hangVines(level, box, cx + lx, y - 1, cz + lz, 1 + (int) (shape.rnd(lx, 55, lz) * 3.0D), 0.4D);
                }
            }
        }
    }

    private void placeCenterpiece(WorldGenLevel level, BoundingBox box, RandomSource random) {
        // peana y escalones
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                put(level, box, cx + dx, top + 1, cz + dz, dx == 0 && dz == 0 ? CHISELED : BRICK_SLAB);
            }
        }
        // estatua
        Direction facing = Direction.from2DDataValue((int) (shape.rnd(1, 2, 3) * 4.0D) & 3);
        BlockState statue = ModBlocks.DRAGON_STATUE.get().defaultBlockState().setValue(IslandStatueBlock.FACING, facing);
        if (box.isInside(cx, top + 2, cz)) {
            BlockPos statuePos = new BlockPos(cx, top + 2, cz);
            level.setBlock(statuePos, statue, 2);
            BlockEntity blockEntity = level.getBlockEntity(statuePos);
            if (blockEntity instanceof IslandStatueBlockEntity data) {
                data.radius = shape.radius;
                data.topY = top;
                data.bottomY = top - 2 - shape.depth - 4;
                data.corridorMinY = Math.min(groundVine, groundFall) - 3;
                data.vineX = cx + shape.vineX;
                data.vineZ = cz + shape.vineZ;
                data.vineSx = shape.vineSx;
                data.vineSz = shape.vineSz;
                data.fallX = cx + shape.fallX;
                data.fallZ = cz + shape.fallZ;
                data.setChanged();
            }
        }
        // dos cofres junto a los pilares
        int[] chestPillars = {1, 5};
        for (int idx : chestPillars) {
            double a = idx * Math.PI / 4.0D + Math.PI / 8.0D;
            int rx = (int) Math.round(Math.cos(a) * (IslaShape.PILLAR_RADIUS - 1.2D));
            int rz = (int) Math.round(Math.sin(a) * (IslaShape.PILLAR_RADIUS - 1.2D));
            if (shape.inShrine(rx, rz, 1) || shape.nearLake(rx, rz, 1.5D) || shape.nearChannel(rx, rz)) {
                continue;
            }
            Direction dir = Math.abs(rx) > Math.abs(rz)
                    ? (rx > 0 ? Direction.WEST : Direction.EAST)
                    : (rz > 0 ? Direction.NORTH : Direction.SOUTH);
            BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, dir);
            createChest(level, box, random, new BlockPos(cx + rx, top + 1, cz + rz), CHEST_LOOT, chest);
        }
    }

    // ------------------------------------------------------------------ arboles

    private void placeTrees(WorldGenLevel level, BoundingBox box) {
        int gi0 = Math.floorDiv(box.minX() - cx - 4, 6);
        int gi1 = Math.floorDiv(box.maxX() - cx + 4, 6);
        int gj0 = Math.floorDiv(box.minZ() - cz - 4, 6);
        int gj1 = Math.floorDiv(box.maxZ() - cz + 4, 6);
        for (int gi = gi0; gi <= gi1; gi++) {
            for (int gj = gj0; gj <= gj1; gj++) {
                if (shape.rnd(gi, 5, gj) > 0.5D) {
                    continue;
                }
                int tx = gi * 6 + (int) (shape.rnd(gi, 6, gj) * 6.0D);
                int tz = gj * 6 + (int) (shape.rnd(gi, 7, gj) * 6.0D);
                if (!shape.inside(tx, tz) || shape.frac(tx, tz) > 0.78D || tx * tx + tz * tz < 144
                        || shape.nearLake(tx, tz, 1.7D) || shape.nearChannel(tx, tz) || shape.inShrine(tx, tz, 4)) {
                    continue;
                }
                int ty = top + shape.topOffset(tx, tz) + 1;
                placeTree(level, box, cx + tx, ty, cz + tz, shape.rnd(gi, 8, gj), gi, gj);
            }
        }
    }

    private void placeTree(WorldGenLevel level, BoundingBox box, int x, int y, int z, double kind, int gi, int gj) {
        BlockState log;
        BlockState leafA;
        BlockState leafB;
        int height;
        if (kind < 0.5D) {
            log = Blocks.CHERRY_LOG.defaultBlockState();
            leafA = leaves(Blocks.CHERRY_LEAVES.defaultBlockState());
            leafB = leafA;
            height = 4 + (int) (shape.rnd(gi, 9, gj) * 2.0D);
        } else if (kind < 0.8D) {
            log = Blocks.OAK_LOG.defaultBlockState();
            leafA = leaves(Blocks.OAK_LEAVES.defaultBlockState());
            leafB = leafA;
            height = 4 + (int) (shape.rnd(gi, 9, gj) * 3.0D);
        } else {
            log = Blocks.OAK_LOG.defaultBlockState();
            leafA = leaves(Blocks.AZALEA_LEAVES.defaultBlockState());
            leafB = leaves(Blocks.FLOWERING_AZALEA_LEAVES.defaultBlockState());
            height = 3 + (int) (shape.rnd(gi, 9, gj) * 2.0D);
        }
        for (int k = 0; k < height; k++) {
            put(level, box, x, y + k, z, log);
        }
        int ly = y + height;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -3; dz <= 3; dz++) {
                    double dist = dx * dx + dy * dy * 1.6D + dz * dz;
                    if (dist > 7.5D || (dx == 0 && dz == 0 && dy <= 0)) {
                        continue;
                    }
                    if (shape.rnd(x + dx, ly + dy, z + dz) < 0.1D) {
                        continue;
                    }
                    BlockState leaf = shape.rnd(x + dx, ly + dy + 100, z + dz) < 0.3D ? leafB : leafA;
                    putIfAir(level, box, x + dx, ly + dy, z + dz, leaf);
                }
            }
        }
    }

    // ------------------------------------------- enredadera gigante y cascada

    private BlockState trunkBlock(int rx, int y, int rz) {
        double r = shape.rnd(rx, y, rz + 5);
        if (r < 0.55D) {
            return MOSS_BLOCK;
        }
        return r < 0.85D ? MANGROVE_ROOTS : MUDDY_ROOTS;
    }

    private void placeVine(WorldGenLevel level, BoundingBox box) {
        int vx = cx + shape.vineX;
        int vz = cz + shape.vineZ;
        int x0 = Math.max(box.minX(), vx - 6);
        int x1 = Math.min(box.maxX(), vx + 6);
        int z0 = Math.max(box.minZ(), vz - 6);
        int z1 = Math.min(box.maxZ(), vz + 6);
        if (x0 > x1 || z0 > z1) {
            return;
        }
        int yMax = top + 1;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                int rx = x - cx;
                int rz = z - cz;
                for (int y = trunkBase; y <= yMax; y++) {
                    if (isTrunk(rx, y, rz)) {
                        put(level, box, x, y, z, trunkBlock(rx, y, rz));
                        continue;
                    }
                    if (y < groundVine) {
                        continue;
                    }
                    boolean north = isTrunk(rx, y, rz - 1);
                    boolean south = isTrunk(rx, y, rz + 1);
                    boolean west = isTrunk(rx - 1, y, rz);
                    boolean east = isTrunk(rx + 1, y, rz);
                    if (!(north || south || west || east) || !isAirAt(level, box, x, y, z)) {
                        continue;
                    }
                    BlockState vine = Blocks.VINE.defaultBlockState()
                            .setValue(VineBlock.NORTH, north)
                            .setValue(VineBlock.SOUTH, south)
                            .setValue(VineBlock.WEST, west)
                            .setValue(VineBlock.EAST, east);
                    put(level, box, x, y, z, vine);
                }
            }
        }

        // copa de azalea sobre el extremo superior, fuera del camino hacia la isla
        int topIdx = top + 1 - trunkBase;
        double centerX = trunkAx[topIdx] + shape.vineSx * 0.5D;
        double centerZ = trunkAz[topIdx] + shape.vineSz * 0.5D;
        for (int dx = -3; dx <= 4; dx++) {
            for (int dz = -3; dz <= 4; dz++) {
                int rx = trunkAx[topIdx] + dx;
                int rz = trunkAz[topIdx] + dz;
                double dist = Math.sqrt((rx - centerX) * (rx - centerX) + (rz - centerZ) * (rz - centerZ));
                if (dist > 2.7D || shape.inside(rx, rz) || isTrunk(rx, top + 1, rz)) {
                    continue;
                }
                for (int k = 2; k <= 3; k++) {
                    if (shape.rnd(rx, top + k, rz) < 0.55D) {
                        putIfAir(level, box, cx + rx, top + k, cz + rz,
                                leaves(Blocks.FLOWERING_AZALEA_LEAVES.defaultBlockState()));
                    }
                }
            }
        }
    }

    private void placeWaterfall(WorldGenLevel level, BoundingBox box) {
        int fx = cx + shape.fallX;
        int fz = cz + shape.fallZ;
        if (box.isInside(fx, top - 1, fz)) {
            put(level, box, fx, top - 1, fz, FLOW_TOP);
            level.scheduleTick(new BlockPos(fx, top - 1, fz), Fluids.WATER, 0);
            for (int y = top - 2; y >= groundFall; y--) {
                put(level, box, fx, y, fz, FALLING_WATER);
            }
            level.scheduleTick(new BlockPos(fx, top - 2, fz), Fluids.WATER, 0);
        }
        if (!overWater) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    int px = fx + dx;
                    int pz = fz + dz;
                    int py = groundFall - 1;
                    if (box.isInside(px, py, pz) && !level.getBlockState(new BlockPos(px, py, pz)).isAir()) {
                        put(level, box, px, py, pz, WATER);
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- dragoncitos

    private void spawnDragons(WorldGenLevel level, BoundingBox box) {
        for (int[] spawn : shape.spawns) {
            int x = cx + spawn[0];
            int z = cz + spawn[1];
            int y = top + shape.topOffset(spawn[0], spawn[1]) + 1;
            if (!box.isInside(x, y, z)) {
                continue;
            }
            DragoncitoEntity dragon = ModEntities.DRAGONCITO.get().create(level.getLevel());
            if (dragon == null) {
                continue;
            }
            BlockPos pos = new BlockPos(x, y, z);
            dragon.moveTo(x + 0.5D, y, z + 0.5D, (float) (shape.rnd(spawn[0], 60, spawn[1]) * 360.0D), 0.0F);
            dragon.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
            dragon.setHome(new BlockPos(cx, top + 1, cz), shape.radius + 4);
            dragon.setPersistenceRequired();
            level.addFreshEntityWithPassengers(dragon);
        }
    }
}
