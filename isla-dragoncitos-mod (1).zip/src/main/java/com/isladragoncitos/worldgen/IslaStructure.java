package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/**
 * Isla flotante. Busca un rio cercano para que la cascada caiga en el: si lo encuentra, la isla
 * se coloca justo encima; si no, solo aparece de vez en cuando (la cascada cae a un estanque).
 */
public class IslaStructure extends Structure {
    public static final Codec<IslaStructure> CODEC = simpleCodec(IslaStructure::new);

    /** Probabilidad (%) de que aparezca una isla aunque no haya ningun rio cerca. */
    private static final int NO_RIVER_CHANCE = 25;
    private static final int RIVER_SEARCH = 48;

    public IslaStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.ISLA_TYPE.get();
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunkPos = context.chunkPos();
        int mx = chunkPos.getMiddleBlockX();
        int mz = chunkPos.getMiddleBlockZ();
        WorldgenRandom random = context.random();

        long seed = random.nextLong();
        int radius = 22 + random.nextInt(6);
        double fallAngle = random.nextDouble() * Math.PI * 2.0D;
        IslaShape shape = new IslaShape(seed, radius, fallAngle);

        int cx;
        int cz;
        int[] river = findRiver(context, mx, mz);
        if (river != null) {
            cx = river[0] - shape.fallX;
            cz = river[1] - shape.fallZ;
        } else {
            if (random.nextInt(100) >= NO_RIVER_CHANCE) {
                return Optional.empty();
            }
            cx = mx;
            cz = mz;
        }

        int fx = cx + shape.fallX;
        int fz = cz + shape.fallZ;
        int vx = cx + shape.vineX;
        int vz = cz + shape.vineZ;

        int groundFall = height(context, fx, fz);
        int groundVine = height(context, vx, vz);
        int maxHeight = Math.max(groundFall, groundVine);
        maxHeight = Math.max(maxHeight, height(context, cx, cz));
        for (int i = 0; i < 8; i++) {
            double angle = i * Math.PI / 4.0D;
            int sx = cx + (int) Math.round(Math.cos(angle) * (radius - 3));
            int sz = cz + (int) Math.round(Math.sin(angle) * (radius - 3));
            maxHeight = Math.max(maxHeight, height(context, sx, sz));
        }

        int top = maxHeight + 42 + random.nextInt(10);
        int cap = context.heightAccessor().getMaxBuildHeight() - 40;
        if (top > cap) {
            top = cap;
        }
        if (top < groundFall + 25 || top < groundVine + 25) {
            return Optional.empty();
        }

        boolean overWater = isWater(context, fx, groundFall - 1, fz);
        IslaPiece piece = new IslaPiece(cx, cz, top, radius, seed, fallAngle, groundVine, groundFall, overWater);
        BlockPos start = new BlockPos(cx, groundFall, cz);
        return Optional.of(new Structure.GenerationStub(start, builder -> builder.addPiece(piece)));
    }

    private static int height(Structure.GenerationContext context, int x, int z) {
        return context.chunkGenerator().getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG,
                context.heightAccessor(), context.randomState());
    }

    private static boolean isWater(Structure.GenerationContext context, int x, int y, int z) {
        return context.chunkGenerator()
                .getBaseColumn(x, z, context.heightAccessor(), context.randomState())
                .getBlock(y).is(Blocks.WATER);
    }

    /** Punto de agua de un rio cercano (el mas proximo al centro del chunk), o null si no hay. */
    private static int[] findRiver(Structure.GenerationContext context, int mx, int mz) {
        int bestDistance = Integer.MAX_VALUE;
        int bx = 0;
        int bz = 0;
        boolean found = false;
        for (int dx = -RIVER_SEARCH; dx <= RIVER_SEARCH; dx += 4) {
            for (int dz = -RIVER_SEARCH; dz <= RIVER_SEARCH; dz += 4) {
                int d = dx * dx + dz * dz;
                if (d >= bestDistance) {
                    continue;
                }
                Holder<Biome> biome = context.biomeSource().getNoiseBiome(
                        QuartPos.fromBlock(mx + dx), QuartPos.fromBlock(63), QuartPos.fromBlock(mz + dz),
                        context.randomState().sampler());
                if (biome.is(BiomeTags.IS_RIVER)) {
                    bestDistance = d;
                    bx = mx + dx;
                    bz = mz + dz;
                    found = true;
                }
            }
        }
        if (!found) {
            return null;
        }

        // afina hasta una columna que realmente tenga agua
        int seaY = context.chunkGenerator().getSeaLevel() - 1;
        int bestWater = Integer.MAX_VALUE;
        int wx = bx;
        int wz = bz;
        for (int dx = -8; dx <= 8; dx += 2) {
            for (int dz = -8; dz <= 8; dz += 2) {
                int d = dx * dx + dz * dz;
                if (d < bestWater && isWater(context, bx + dx, seaY, bz + dz)) {
                    bestWater = d;
                    wx = bx + dx;
                    wz = bz + dz;
                }
            }
        }
        return new int[]{wx, wz};
    }
}
