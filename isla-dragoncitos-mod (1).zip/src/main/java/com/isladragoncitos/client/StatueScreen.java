package com.isladragoncitos.client;

import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.network.StatueInfo;
import com.isladragoncitos.network.TeleportIslandPacket;
import com.isladragoncitos.network.TrustPacket;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

/** Menu de la estatua: viajar a otras islas y (si eres el duenio) gestionar permisos. */
public class StatueScreen extends Screen {
    private static final int PER_PAGE = 3;

    private final StatueInfo info;
    private int page = 0;
    private EditBox playerBox;

    public StatueScreen(StatueInfo info) {
        super(Component.literal(info.islandName()));
        this.info = info;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 120;
        List<StatueInfo.Destination> destinations = this.info.destinations();

        int start = this.page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < destinations.size(); i++) {
            StatueInfo.Destination destination = destinations.get(start + i);
            Component label = destination.ownerName().equals(this.info.ownerName())
                    ? Component.literal(destination.name())
                    : Component.translatable("screen.isladragoncitos.destination_of",
                            destination.name(), destination.ownerName());
            this.addRenderableWidget(Button.builder(label, button -> {
                ModNetwork.CHANNEL.sendToServer(new TeleportIslandPacket(this.info.statuePos(), destination.pos()));
                this.onClose();
            }).bounds(cx - 100, top + 40 + i * 22, 200, 20).build());
        }

        if (destinations.size() > PER_PAGE) {
            Button prev = Button.builder(Component.literal("<"), button -> {
                this.page--;
                this.rebuildWidgets();
            }).bounds(cx - 100, top + 108, 98, 20).build();
            prev.active = this.page > 0;
            Button next = Button.builder(Component.literal(">"), button -> {
                this.page++;
                this.rebuildWidgets();
            }).bounds(cx + 2, top + 108, 98, 20).build();
            next.active = start + PER_PAGE < destinations.size();
            this.addRenderableWidget(prev);
            this.addRenderableWidget(next);
        }

        int doneY = top + 138;
        if (this.info.owner()) {
            this.playerBox = new EditBox(this.font, cx - 100, top + 150, 200, 20,
                    Component.translatable("screen.isladragoncitos.player_hint"));
            this.playerBox.setMaxLength(16);
            this.playerBox.setHint(Component.translatable("screen.isladragoncitos.player_hint"));
            this.addRenderableWidget(this.playerBox);
            this.addRenderableWidget(Button.builder(Component.translatable("screen.isladragoncitos.trust_add"),
                    button -> sendTrust(true)).bounds(cx - 100, top + 174, 98, 20).build());
            this.addRenderableWidget(Button.builder(Component.translatable("screen.isladragoncitos.trust_remove"),
                    button -> sendTrust(false)).bounds(cx + 2, top + 174, 98, 20).build());
            doneY = top + 214;
        }
        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> this.onClose())
                .bounds(cx - 100, doneY, 200, 20).build());
    }

    private void sendTrust(boolean add) {
        String name = this.playerBox.getValue().trim();
        if (!name.isEmpty()) {
            ModNetwork.CHANNEL.sendToServer(new TrustPacket(this.info.statuePos(), name, add));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int cx = this.width / 2;
        int top = this.height / 2 - 120;

        graphics.drawCenteredString(this.font, Component.literal(this.info.islandName()).withStyle(ChatFormatting.BOLD),
                cx, top, 0xFFFFFF);
        graphics.drawCenteredString(this.font,
                Component.translatable("screen.isladragoncitos.owner", this.info.ownerName()), cx, top + 14, 0xAAAAAA);
        Component travel = this.info.destinations().isEmpty()
                ? Component.translatable("screen.isladragoncitos.no_destinations")
                : Component.translatable("screen.isladragoncitos.travel");
        graphics.drawCenteredString(this.font, travel, cx, top + 28, 0xFFD27F);

        if (this.info.owner()) {
            graphics.drawCenteredString(this.font, Component.translatable("screen.isladragoncitos.permissions"),
                    cx, top + 138, 0xFFD27F);
            String names = this.info.trusted().isEmpty() ? "-" : String.join(", ", this.info.trusted());
            Component trustedLine = Component.translatable("screen.isladragoncitos.trusted", names);
            int y = top + 198;
            for (FormattedCharSequence line : this.font.split(FormattedText.of(trustedLine.getString()), 200)) {
                if (y > top + 198) {
                    break;
                }
                graphics.drawString(this.font, line, cx - 100, y, 0xBBBBBB, false);
                y += 10;
            }
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
