package com.isladragoncitos.client;

import com.isladragoncitos.network.StatueInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Puntos de entrada del cliente (se llaman desde los paquetes via DistExecutor). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openNameScreen(BlockPos pos) {
        Minecraft.getInstance().setScreen(new NameIslandScreen(pos));
    }

    public static void openStatueScreen(StatueInfo info) {
        Minecraft.getInstance().setScreen(new StatueScreen(info));
    }
}
