package com.isladragoncitos.client;

import com.isladragoncitos.network.ClaimIslandPacket;
import com.isladragoncitos.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** Pantalla para ponerle nombre a la isla y hacerla tuya. */
public class NameIslandScreen extends Screen {
    private final BlockPos pos;
    private EditBox nameBox;

    public NameIslandScreen(BlockPos pos) {
        super(Component.translatable("screen.isladragoncitos.name_title"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;
        this.nameBox = new EditBox(this.font, cx - 100, cy - 10, 200, 20,
                Component.translatable("screen.isladragoncitos.name_hint"));
        this.nameBox.setMaxLength(24);
        this.nameBox.setHint(Component.translatable("screen.isladragoncitos.name_hint"));
        this.addRenderableWidget(this.nameBox);
        this.setInitialFocus(this.nameBox);

        this.addRenderableWidget(Button.builder(Component.translatable("screen.isladragoncitos.claim"), button -> claim())
                .bounds(cx - 100, cy + 20, 200, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), button -> this.onClose())
                .bounds(cx - 100, cy + 44, 200, 20).build());
    }

    private void claim() {
        String name = this.nameBox.getValue().trim();
        if (name.isEmpty()) {
            return;
        }
        ModNetwork.CHANNEL.sendToServer(new ClaimIslandPacket(this.pos, name));
        this.onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) {
            claim();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int cx = this.width / 2;
        int cy = this.height / 2;
        graphics.drawCenteredString(this.font, this.title, cx, cy - 46, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("screen.isladragoncitos.name_info"), cx, cy - 30, 0xBBBBBB);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
