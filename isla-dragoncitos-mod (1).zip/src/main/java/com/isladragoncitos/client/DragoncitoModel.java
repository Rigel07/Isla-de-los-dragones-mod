package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.DragoncitoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo del dragoncito: cabezon, hocico corto, cuernitos, alas pequenas y cola con punta. */
public class DragoncitoModel extends EntityModel<DragoncitoEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(IslaDragoncitosMod.MODID, "dragoncito"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart tailTip;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;

    public DragoncitoModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.tail = this.body.getChild("tail");
        this.tailTip = this.tail.getChild("tail_tip");
        this.wingLeft = this.body.getChild("wing_left");
        this.wingRight = this.body.getChild("wing_right");
        this.legFrontLeft = this.body.getChild("leg_front_left");
        this.legFrontRight = this.body.getChild("leg_front_right");
        this.legBackLeft = this.body.getChild("leg_back_left");
        this.legBackRight = this.body.getChild("leg_back_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 8.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));

        body.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 14).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 5.0F)
                        .texOffs(28, 0).addBox(-1.5F, 0.0F, -7.0F, 3.0F, 2.0F, 2.0F)
                        .texOffs(38, 0).addBox(1.0F, -5.0F, -2.0F, 1.0F, 2.0F, 1.0F)
                        .texOffs(42, 0).addBox(-2.0F, -5.0F, -2.0F, 1.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, -2.0F, -4.0F));

        PartDefinition tail = body.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(28, 4).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 5.0F),
                PartPose.offset(0.0F, 1.0F, 4.0F));
        tail.addOrReplaceChild("tail_tip",
                CubeListBuilder.create().texOffs(44, 4).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F),
                PartPose.offset(0.0F, 0.0F, 5.0F));

        body.addOrReplaceChild("wing_left",
                CubeListBuilder.create().texOffs(0, 25).addBox(0.0F, -0.5F, -2.5F, 7.0F, 1.0F, 5.0F),
                PartPose.offset(3.0F, -2.5F, -1.0F));
        body.addOrReplaceChild("wing_right",
                CubeListBuilder.create().texOffs(24, 25).addBox(-7.0F, -0.5F, -2.5F, 7.0F, 1.0F, 5.0F),
                PartPose.offset(-3.0F, -2.5F, -1.0F));

        body.addOrReplaceChild("leg_front_left",
                CubeListBuilder.create().texOffs(46, 12).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(2.0F, 3.0F, -2.5F));
        body.addOrReplaceChild("leg_front_right",
                CubeListBuilder.create().texOffs(54, 12).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(-2.0F, 3.0F, -2.5F));
        body.addOrReplaceChild("leg_back_left",
                CubeListBuilder.create().texOffs(46, 12).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(2.0F, 3.0F, 2.5F));
        body.addOrReplaceChild("leg_back_right",
                CubeListBuilder.create().texOffs(54, 12).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(-2.0F, 3.0F, 2.5F));

        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(DragoncitoEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180.0F);
        this.head.xRot = headPitch * ((float) Math.PI / 180.0F);

        boolean sitting = entity.isInSittingPose();
        boolean flying = entity.isFlying() && !sitting;

        this.body.y = sitting ? 20.0F : 19.0F;
        this.body.xRot = sitting ? -0.3F : 0.0F;

        if (flying) {
            float flap = Mth.cos(ageInTicks * 1.2F) * 0.75F;
            this.wingLeft.zRot = flap - 0.15F;
            this.wingRight.zRot = -this.wingLeft.zRot;
            this.legFrontLeft.xRot = -0.6F;
            this.legFrontRight.xRot = -0.6F;
            this.legBackLeft.xRot = 0.6F;
            this.legBackRight.xRot = 0.6F;
            this.tail.xRot = -0.2F;
        } else {
            float breathe = Mth.sin(ageInTicks * 0.08F) * 0.04F;
            this.wingLeft.zRot = 0.9F + breathe;
            this.wingRight.zRot = -this.wingLeft.zRot;
            float swing = Mth.cos(limbSwing * 0.6662F) * 1.1F * limbSwingAmount;
            this.legFrontLeft.xRot = swing;
            this.legBackRight.xRot = swing;
            this.legFrontRight.xRot = -swing;
            this.legBackLeft.xRot = -swing;
            this.tail.xRot = 0.1F;
        }

        float sway = Mth.cos(ageInTicks * 0.12F) * 0.15F + Mth.cos(limbSwing * 0.6F) * 0.3F * limbSwingAmount;
        this.tail.yRot = sitting ? 0.6F : sway;
        this.tailTip.yRot = this.tail.yRot * 1.4F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
