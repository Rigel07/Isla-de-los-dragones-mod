package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.DragoncitoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DragoncitoRenderer extends MobRenderer<DragoncitoEntity, DragoncitoModel> {
    private static final ResourceLocation[] TEXTURES = {
            texture("pink"), texture("green"), texture("blue"), texture("red")
    };

    public DragoncitoRenderer(EntityRendererProvider.Context context) {
        super(context, new DragoncitoModel(context.bakeLayer(DragoncitoModel.LAYER_LOCATION)), 0.3F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "textures/entity/dragoncito_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(DragoncitoEntity entity) {
        return TEXTURES[entity.getVariant()];
    }

    @Override
    protected void scale(DragoncitoEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.25F, 1.25F, 1.25F);
    }
}
