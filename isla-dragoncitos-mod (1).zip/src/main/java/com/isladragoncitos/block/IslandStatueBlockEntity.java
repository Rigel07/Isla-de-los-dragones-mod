package com.isladragoncitos.block;

import com.isladragoncitos.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Guarda la geometria de la isla donde se genero la estatua. Se copia al registro
 * cuando un jugador reclama la isla y sirve para calcular la zona protegida.
 */
public class IslandStatueBlockEntity extends BlockEntity {
    public int radius;
    public int topY;
    public int bottomY;
    public int corridorMinY;
    public int vineX;
    public int vineZ;
    public int vineSx = 1;
    public int vineSz = 1;
    public int fallX;
    public int fallZ;

    public IslandStatueBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STATUE.get(), pos, state);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Radius", radius);
        tag.putInt("TopY", topY);
        tag.putInt("BottomY", bottomY);
        tag.putInt("CorridorMinY", corridorMinY);
        tag.putInt("VineX", vineX);
        tag.putInt("VineZ", vineZ);
        tag.putInt("VineSx", vineSx);
        tag.putInt("VineSz", vineSz);
        tag.putInt("FallX", fallX);
        tag.putInt("FallZ", fallZ);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        radius = tag.getInt("Radius");
        topY = tag.getInt("TopY");
        bottomY = tag.getInt("BottomY");
        corridorMinY = tag.getInt("CorridorMinY");
        vineX = tag.getInt("VineX");
        vineZ = tag.getInt("VineZ");
        vineSx = tag.contains("VineSx") ? tag.getInt("VineSx") : 1;
        vineSz = tag.contains("VineSz") ? tag.getInt("VineSz") : 1;
        fallX = tag.getInt("FallX");
        fallZ = tag.getInt("FallZ");
    }
}
