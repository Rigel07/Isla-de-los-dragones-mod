package com.isladragoncitos;

import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.registry.ModBlockEntities;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModCreativeTabs;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModItems;
import com.isladragoncitos.registry.ModStructures;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(IslaDragoncitosMod.MODID)
public class IslaDragoncitosMod {
    public static final String MODID = "isladragoncitos";

    public IslaDragoncitosMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModStructures.STRUCTURE_TYPES.register(modBus);
        ModStructures.STRUCTURE_PIECES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
