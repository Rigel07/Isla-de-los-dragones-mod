package com.isladragoncitos.island;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.block.IslandStatueBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** Solo el duenio y los jugadores con permiso pueden entrar, destruir y construir en una isla reclamada. */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class ProtectionEvents {
    private ProtectionEvents() {}

    private static boolean isBlocked(Player player, BlockPos pos) {
        if (!(player.level() instanceof ServerLevel level) || player.hasPermissions(2)) {
            return false;
        }
        if (level.dimension() != Level.OVERWORLD) {
            return false;
        }
        Island island = IslandRegistry.get(level.getServer()).findAt(pos);
        if (island == null || island.canAccess(player.getUUID())) {
            return false;
        }
        player.displayClientMessage(Component.translatable("message.isladragoncitos.protected",
                island.name, island.ownerName), true);
        return true;
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (isBlocked(event.getPlayer(), event.getPos())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof Player player && isBlocked(player, event.getPos())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (event.getLevel().getBlockState(event.getPos()).getBlock() instanceof IslandStatueBlock) {
            return;
        }
        BlockPos target = event.getPos();
        BlockPos placed = target.relative(event.getFace() == null ? net.minecraft.core.Direction.UP : event.getFace());
        if (isBlocked(event.getEntity(), target) || isBlocked(event.getEntity(), placed)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        if (isBlocked(event.getEntity(), event.getPos())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onBucket(FillBucketEvent event) {
        HitResult target = event.getTarget();
        if (target instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = hit.getBlockPos();
            if (isBlocked(event.getEntity(), pos) || isBlocked(event.getEntity(), pos.relative(hit.getDirection()))) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
            return;
        }
        IslandRegistry registry = IslandRegistry.get(level.getServer());
        event.getAffectedBlocks().removeIf(pos -> registry.findAt(pos) != null);
    }

    /** Quien no tenga permiso no puede quedarse dentro de la isla: se le devuelve al pie de la enredadera. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER
                || event.player.tickCount % 20 != 0) {
            return;
        }
        if (!(event.player instanceof ServerPlayer player) || player.isSpectator() || player.hasPermissions(2)) {
            return;
        }
        if (!(player.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
            return;
        }
        IslandRegistry registry = IslandRegistry.get(level.getServer());
        BlockPos here = player.blockPosition();
        for (Island island : registry.all()) {
            if (island.radius > 0 && !island.canAccess(player.getUUID()) && island.inCore(here)) {
                expel(player, level, island);
                return;
            }
        }
    }

    private static void expel(ServerPlayer player, ServerLevel level, Island island) {
        int x = island.vineX + 5 * island.vineSx;
        int z = island.vineZ + 5 * island.vineSz;
        level.getChunk(new ChunkPos(new BlockPos(x, 0, z)).x, new ChunkPos(new BlockPos(x, 0, z)).z);
        int y = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z)).getY();
        player.teleportTo(level, x + 0.5D, y, z + 0.5D, player.getYRot(), player.getXRot());
        player.fallDistance = 0.0F;
        player.displayClientMessage(Component.translatable("message.isladragoncitos.expelled",
                island.name, island.ownerName), true);
    }
}
