package com.isladragoncitos.island;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

/** Una isla reclamada: nombre, duenio, jugadores con permiso y zona protegida. */
public class Island {
    public final BlockPos pos;
    public String name;
    public UUID owner;
    public String ownerName;
    public final Map<UUID, String> trusted = new LinkedHashMap<>();

    public int radius;
    public int topY;
    public int bottomY;
    public int corridorMinY;
    public int vineX;
    public int vineZ;
    public int vineSx = 1;
    public int vineSz = 1;
    public int fallX;
    public int fallZ;

    public Island(BlockPos pos, String name, UUID owner, String ownerName) {
        this.pos = pos;
        this.name = name;
        this.owner = owner;
        this.ownerName = ownerName;
    }

    public boolean isOwner(UUID id) {
        return owner.equals(id);
    }

    public boolean canAccess(UUID id) {
        return owner.equals(id) || trusted.containsKey(id);
    }

    /** Zona principal: el cilindro de la isla flotante. */
    public boolean inCore(BlockPos p) {
        if (radius <= 0) {
            return false;
        }
        int dx = p.getX() - pos.getX();
        int dz = p.getZ() - pos.getZ();
        int r = radius + 2;
        return dx * dx + dz * dz <= r * r && p.getY() >= bottomY && p.getY() <= topY + 40;
    }

    /** Todo lo protegido: la isla, la enredadera y la cascada. */
    public boolean contains(BlockPos p) {
        if (radius <= 0) {
            return false;
        }
        if (inCore(p)) {
            return true;
        }
        if (Math.abs(p.getX() - vineX) <= 4 && Math.abs(p.getZ() - vineZ) <= 4
                && p.getY() >= corridorMinY && p.getY() <= topY + 8) {
            return true;
        }
        return Math.abs(p.getX() - fallX) <= 1 && Math.abs(p.getZ() - fallZ) <= 1
                && p.getY() >= corridorMinY && p.getY() <= topY;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putLong("Pos", pos.asLong());
        tag.putString("Name", name);
        tag.putUUID("Owner", owner);
        tag.putString("OwnerName", ownerName);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, String> entry : trusted.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", entry.getKey());
            t.putString("Name", entry.getValue());
            list.add(t);
        }
        tag.put("Trusted", list);
        tag.putInt("Radius", radius);
        tag.putInt("TopY", topY);
        tag.putInt("BottomY", bottomY);
        tag.putInt("CorridorMinY", corridorMinY);
        tag.putInt("VineX", vineX);
        tag.putInt("VineZ", vineZ);
        tag.putInt("VineSx", vineSx);
        tag.putInt("VineSz", vineSz);
        tag.putInt("FallX", fallX);
        tag.putInt("FallZ", fallZ);
        return tag;
    }

    public static Island load(CompoundTag tag) {
        Island island = new Island(BlockPos.of(tag.getLong("Pos")), tag.getString("Name"),
                tag.getUUID("Owner"), tag.getString("OwnerName"));
        ListTag list = tag.getList("Trusted", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            island.trusted.put(t.getUUID("Id"), t.getString("Name"));
        }
        island.radius = tag.getInt("Radius");
        island.topY = tag.getInt("TopY");
        island.bottomY = tag.getInt("BottomY");
        island.corridorMinY = tag.getInt("CorridorMinY");
        island.vineX = tag.getInt("VineX");
        island.vineZ = tag.getInt("VineZ");
        island.vineSx = tag.contains("VineSx") ? tag.getInt("VineSx") : 1;
        island.vineSz = tag.contains("VineSz") ? tag.getInt("VineSz") : 1;
        island.fallX = tag.getInt("FallX");
        island.fallZ = tag.getInt("FallZ");
        return island;
    }
}
