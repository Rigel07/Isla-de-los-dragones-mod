package com.isladragoncitos.island;

import com.isladragoncitos.block.IslandStatueBlock;
import com.isladragoncitos.block.IslandStatueBlockEntity;
import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.network.OpenNameScreenPacket;
import com.isladragoncitos.network.OpenStatueScreenPacket;
import com.isladragoncitos.network.StatueInfo;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Logica de servidor de las islas: reclamar, viajar y gestionar permisos. */
public final class IslandService {
    private static final double MAX_DISTANCE_SQR = 12.0D * 12.0D;

    private IslandService() {}

    /** Clic derecho sobre la estatua. */
    public static void interact(ServerPlayer player, BlockPos pos) {
        IslandRegistry registry = IslandRegistry.get(player.server);
        Island island = registry.get(pos);
        if (island == null) {
            ModNetwork.sendTo(player, new OpenNameScreenPacket(pos));
            return;
        }
        if (island.canAccess(player.getUUID())) {
            registry.discover(player.getUUID(), pos);
            sendStatueScreen(player, island);
        } else {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.owned_by",
                    island.name, island.ownerName), true);
        }
    }

    public static void sendStatueScreen(ServerPlayer player, Island island) {
        IslandRegistry registry = IslandRegistry.get(player.server);
        List<StatueInfo.Destination> destinations = new ArrayList<>();
        for (Island other : registry.destinationsFor(player.getUUID(), island.pos)) {
            destinations.add(new StatueInfo.Destination(other.pos, other.name, other.ownerName));
        }
        List<String> trusted = new ArrayList<>(island.trusted.values());
        StatueInfo info = new StatueInfo(island.pos, island.name, island.ownerName,
                island.isOwner(player.getUUID()), destinations, trusted);
        ModNetwork.sendTo(player, new OpenStatueScreenPacket(info));
    }

    public static void claim(ServerPlayer player, BlockPos pos, String rawName) {
        if (!isNearStatue(player, pos)) {
            return;
        }
        IslandRegistry registry = IslandRegistry.get(player.server);
        if (registry.get(pos) != null) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.already_claimed"), true);
            return;
        }
        String name = sanitize(rawName);
        if (name.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.empty_name"), true);
            return;
        }

        Island island = new Island(pos, name, player.getUUID(), player.getGameProfile().getName());
        BlockEntity blockEntity = player.level().getBlockEntity(pos);
        if (blockEntity instanceof IslandStatueBlockEntity statue) {
            island.radius = statue.radius;
            island.topY = statue.topY;
            island.bottomY = statue.bottomY;
            island.corridorMinY = statue.corridorMinY;
            island.vineX = statue.vineX;
            island.vineZ = statue.vineZ;
            island.vineSx = statue.vineSx;
            island.vineSz = statue.vineSz;
            island.fallX = statue.fallX;
            island.fallZ = statue.fallZ;
        }
        registry.add(island);
        registry.discover(player.getUUID(), pos);

        player.displayClientMessage(Component.translatable("message.isladragoncitos.claimed", name), false);
        player.level().playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    public static void teleport(ServerPlayer player, BlockPos from, BlockPos to) {
        if (!isNearStatue(player, from) || from.equals(to)) {
            return;
        }
        MinecraftServer server = player.server;
        IslandRegistry registry = IslandRegistry.get(server);
        Island fromIsland = registry.get(from);
        Island destination = registry.get(to);
        UUID id = player.getUUID();
        if (fromIsland == null || destination == null
                || !fromIsland.canAccess(id) || !destination.canAccess(id)
                || !registry.hasDiscovered(id, to)) {
            return;
        }

        ServerLevel level = server.overworld();
        double x = to.getX() + 0.5D;
        double y = to.getY() - 1.0D;
        double z = to.getZ() + 4.5D;
        level.getChunk(to.getX() >> 4, (int) Math.floor(z) >> 4);

        player.level().playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
        player.teleportTo(level, x, y, z, player.getYRot(), 0.0F);
        player.fallDistance = 0.0F;
        level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
        player.displayClientMessage(Component.translatable("message.isladragoncitos.teleported", destination.name), true);
    }

    public static void trust(ServerPlayer player, BlockPos pos, String targetName, boolean add) {
        if (!isNearStatue(player, pos)) {
            return;
        }
        MinecraftServer server = player.server;
        IslandRegistry registry = IslandRegistry.get(server);
        Island island = registry.get(pos);
        if (island == null || !island.isOwner(player.getUUID())) {
            player.displayClientMessage(Component.translatable("message.isladragoncitos.not_owner"), true);
            return;
        }
        String name = targetName.trim();
        if (name.isEmpty()) {
            return;
        }

        if (add) {
            ServerPlayer online = server.getPlayerList().getPlayerByName(name);
            UUID targetId = null;
            String realName = name;
            if (online != null) {
                targetId = online.getUUID();
                realName = online.getGameProfile().getName();
            } else {
                GameProfileCache cache = server.getProfileCache();
                if (cache != null) {
                    Optional<GameProfile> profile = cache.get(name);
                    if (profile.isPresent()) {
                        targetId = profile.get().getId();
                        realName = profile.get().getName();
                    }
                }
            }
            if (targetId == null) {
                player.displayClientMessage(Component.translatable("message.isladragoncitos.player_not_found", name), true);
                return;
            }
            if (island.isOwner(targetId)) {
                return;
            }
            island.trusted.put(targetId, realName);
            registry.setDirty();
            player.displayClientMessage(Component.translatable("message.isladragoncitos.trust_added", realName), false);
            if (online != null) {
                online.displayClientMessage(Component.translatable("message.isladragoncitos.trust_received",
                        island.name, island.ownerName), false);
            }
        } else {
            UUID removed = null;
            String removedName = name;
            for (Map.Entry<UUID, String> entry : island.trusted.entrySet()) {
                if (entry.getValue().equalsIgnoreCase(name)) {
                    removed = entry.getKey();
                    removedName = entry.getValue();
                    break;
                }
            }
            if (removed == null) {
                player.displayClientMessage(Component.translatable("message.isladragoncitos.player_not_trusted", name), true);
                return;
            }
            island.trusted.remove(removed);
            registry.setDirty();
            player.displayClientMessage(Component.translatable("message.isladragoncitos.trust_removed", removedName), false);
        }
        sendStatueScreen(player, island);
    }

    /** Libera una isla (comando de operador): vuelve a estar sin duenio. */
    public static boolean release(MinecraftServer server, BlockPos near) {
        IslandRegistry registry = IslandRegistry.get(server);
        Island island = registry.nearest(near, 24.0D);
        if (island == null) {
            return false;
        }
        registry.remove(island);
        return true;
    }

    private static boolean isNearStatue(ServerPlayer player, BlockPos pos) {
        Level level = player.level();
        if (player.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > MAX_DISTANCE_SQR) {
            return false;
        }
        return level.getBlockState(pos).getBlock() instanceof IslandStatueBlock;
    }

    private static String sanitize(String raw) {
        StringBuilder builder = new StringBuilder();
        for (char c : raw.trim().toCharArray()) {
            if (c >= 32 && c != '\u00A7' && c != 127) {
                builder.append(c);
            }
        }
        String name = builder.toString().trim();
        return name.length() > 24 ? name.substring(0, 24).trim() : name;
    }
}
