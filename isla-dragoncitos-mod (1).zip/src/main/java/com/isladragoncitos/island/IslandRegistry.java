package com.isladragoncitos.island;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos globales (guardados en el mundo) de todas las islas reclamadas. */
public class IslandRegistry extends SavedData {
    private static final String ID = "isladragoncitos_islas";

    private final Map<Long, Island> islands = new LinkedHashMap<>();
    private final Map<UUID, Set<Long>> discovered = new HashMap<>();

    public static IslandRegistry get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(IslandRegistry::load, IslandRegistry::new, ID);
    }

    @Nullable
    public Island get(BlockPos statuePos) {
        return islands.get(statuePos.asLong());
    }

    public Collection<Island> all() {
        return islands.values();
    }

    /** Isla reclamada cuya zona protegida contiene esta posicion. */
    @Nullable
    public Island findAt(BlockPos pos) {
        for (Island island : islands.values()) {
            if (island.contains(pos)) {
                return island;
            }
        }
        return null;
    }

    @Nullable
    public Island nearest(BlockPos pos, double maxDistance) {
        Island best = null;
        double bestDist = maxDistance * maxDistance;
        for (Island island : islands.values()) {
            double d = island.pos.distSqr(pos);
            if (d <= bestDist) {
                bestDist = d;
                best = island;
            }
        }
        return best;
    }

    public void add(Island island) {
        islands.put(island.pos.asLong(), island);
        setDirty();
    }

    public void remove(Island island) {
        islands.remove(island.pos.asLong());
        for (Set<Long> set : discovered.values()) {
            set.remove(island.pos.asLong());
        }
        setDirty();
    }

    public void discover(UUID player, BlockPos statuePos) {
        if (discovered.computeIfAbsent(player, k -> new HashSet<>()).add(statuePos.asLong())) {
            setDirty();
        }
    }

    public boolean hasDiscovered(UUID player, BlockPos statuePos) {
        Set<Long> set = discovered.get(player);
        return set != null && set.contains(statuePos.asLong());
    }

    /** Islas a las que el jugador puede viajar desde la estatua indicada. */
    public List<Island> destinationsFor(UUID player, BlockPos from) {
        List<Island> result = new ArrayList<>();
        Set<Long> set = discovered.get(player);
        if (set == null) {
            return result;
        }
        for (Long key : set) {
            Island island = islands.get(key);
            if (island != null && island.canAccess(player) && !island.pos.equals(from)) {
                result.add(island);
            }
        }
        return result;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Island island : islands.values()) {
            list.add(island.save());
        }
        tag.put("Islands", list);

        ListTag known = new ListTag();
        for (Map.Entry<UUID, Set<Long>> entry : discovered.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Player", entry.getKey());
            long[] values = new long[entry.getValue().size()];
            int i = 0;
            for (Long l : entry.getValue()) {
                values[i++] = l;
            }
            t.put("Known", new LongArrayTag(values));
            known.add(t);
        }
        tag.put("Discovered", known);
        return tag;
    }

    public static IslandRegistry load(CompoundTag tag) {
        IslandRegistry registry = new IslandRegistry();
        ListTag list = tag.getList("Islands", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Island island = Island.load(list.getCompound(i));
            registry.islands.put(island.pos.asLong(), island);
        }
        ListTag known = tag.getList("Discovered", Tag.TAG_COMPOUND);
        for (int i = 0; i < known.size(); i++) {
            CompoundTag t = known.getCompound(i);
            Set<Long> set = new HashSet<>();
            for (long l : t.getLongArray("Known")) {
                set.add(l);
            }
            registry.discovered.put(t.getUUID("Player"), set);
        }
        return registry;
    }
}
