package com.isladragoncitos.island;

import com.isladragoncitos.IslaDragoncitosMod;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /isladragoncitos release -> libera la isla reclamada mas cercana (solo operadores). */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID)
public final class IslandCommands {
    private IslandCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("isladragoncitos")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("release").executes(context -> release(context.getSource()))));
    }

    private static int release(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        boolean released = IslandService.release(source.getServer(), player.blockPosition());
        if (released) {
            source.sendSuccess(() -> Component.translatable("message.isladragoncitos.released"), true);
            return 1;
        }
        source.sendFailure(Component.translatable("message.isladragoncitos.release_none"));
        return 0;
    }
}
