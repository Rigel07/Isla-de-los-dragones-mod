package com.isladragoncitos.network;

import com.isladragoncitos.client.ClientHooks;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: abre (o refresca) el menu de viaje y permisos de la estatua. */
public record OpenStatueScreenPacket(StatueInfo info) {

    public static void encode(OpenStatueScreenPacket packet, FriendlyByteBuf buf) {
        packet.info().write(buf);
    }

    public static OpenStatueScreenPacket decode(FriendlyByteBuf buf) {
        return new OpenStatueScreenPacket(StatueInfo.read(buf));
    }

    public static void handle(OpenStatueScreenPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openStatueScreen(packet.info())));
        context.get().setPacketHandled(true);
    }
}
