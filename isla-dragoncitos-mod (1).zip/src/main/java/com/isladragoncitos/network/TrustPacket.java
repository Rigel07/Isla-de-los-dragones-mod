package com.isladragoncitos.network;

import com.isladragoncitos.island.IslandService;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: dar o quitar permiso a un jugador en la isla. */
public record TrustPacket(BlockPos pos, String player, boolean add) {

    public static void encode(TrustPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.pos());
        buf.writeUtf(packet.player(), 32);
        buf.writeBoolean(packet.add());
    }

    public static TrustPacket decode(FriendlyByteBuf buf) {
        return new TrustPacket(buf.readBlockPos(), buf.readUtf(32), buf.readBoolean());
    }

    public static void handle(TrustPacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                IslandService.trust(player, packet.pos(), packet.player(), packet.add());
            }
        });
        ctx.setPacketHandled(true);
    }
}
