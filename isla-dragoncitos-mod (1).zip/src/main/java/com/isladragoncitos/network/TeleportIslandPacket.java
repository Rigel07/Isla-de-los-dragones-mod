package com.isladragoncitos.network;

import com.isladragoncitos.island.IslandService;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: viajar desde la estatua actual a la de otra isla. */
public record TeleportIslandPacket(BlockPos from, BlockPos to) {

    public static void encode(TeleportIslandPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.from());
        buf.writeBlockPos(packet.to());
    }

    public static TeleportIslandPacket decode(FriendlyByteBuf buf) {
        return new TeleportIslandPacket(buf.readBlockPos(), buf.readBlockPos());
    }

    public static void handle(TeleportIslandPacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                IslandService.teleport(player, packet.from(), packet.to());
            }
        });
        ctx.setPacketHandled(true);
    }
}
