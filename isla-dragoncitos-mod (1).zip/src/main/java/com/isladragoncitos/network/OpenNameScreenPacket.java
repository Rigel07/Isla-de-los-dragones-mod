package com.isladragoncitos.network;

import com.isladragoncitos.client.ClientHooks;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: abre la pantalla para ponerle nombre a la isla. */
public record OpenNameScreenPacket(BlockPos pos) {

    public static void encode(OpenNameScreenPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.pos());
    }

    public static OpenNameScreenPacket decode(FriendlyByteBuf buf) {
        return new OpenNameScreenPacket(buf.readBlockPos());
    }

    public static void handle(OpenNameScreenPacket packet, Supplier<NetworkEvent.Context> context) {
        context.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openNameScreen(packet.pos())));
        context.get().setPacketHandled(true);
    }
}
