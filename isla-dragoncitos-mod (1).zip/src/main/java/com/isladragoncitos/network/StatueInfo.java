package com.isladragoncitos.network;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

/** Informacion que el servidor manda al cliente para dibujar el menu de la estatua. */
public record StatueInfo(BlockPos statuePos, String islandName, String ownerName, boolean owner,
                         List<Destination> destinations, List<String> trusted) {

    public record Destination(BlockPos pos, String name, String ownerName) {
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeBlockPos(statuePos);
        buf.writeUtf(islandName, 64);
        buf.writeUtf(ownerName, 64);
        buf.writeBoolean(owner);
        buf.writeVarInt(destinations.size());
        for (Destination d : destinations) {
            buf.writeBlockPos(d.pos());
            buf.writeUtf(d.name(), 64);
            buf.writeUtf(d.ownerName(), 64);
        }
        buf.writeVarInt(trusted.size());
        for (String name : trusted) {
            buf.writeUtf(name, 64);
        }
    }

    public static StatueInfo read(FriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        String name = buf.readUtf(64);
        String ownerName = buf.readUtf(64);
        boolean owner = buf.readBoolean();
        int destCount = buf.readVarInt();
        List<Destination> destinations = new ArrayList<>();
        for (int i = 0; i < destCount; i++) {
            destinations.add(new Destination(buf.readBlockPos(), buf.readUtf(64), buf.readUtf(64)));
        }
        int trustedCount = buf.readVarInt();
        List<String> trusted = new ArrayList<>();
        for (int i = 0; i < trustedCount; i++) {
            trusted.add(buf.readUtf(64));
        }
        return new StatueInfo(pos, name, ownerName, owner, destinations, trusted);
    }
}
