package com.isladragoncitos.network;

import com.isladragoncitos.island.IslandService;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: reclamar la isla poniendole nombre. */
public record ClaimIslandPacket(BlockPos pos, String name) {

    public static void encode(ClaimIslandPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.pos());
        buf.writeUtf(packet.name(), 64);
    }

    public static ClaimIslandPacket decode(FriendlyByteBuf buf) {
        return new ClaimIslandPacket(buf.readBlockPos(), buf.readUtf(64));
    }

    public static void handle(ClaimIslandPacket packet, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                IslandService.claim(player, packet.pos(), packet.name());
            }
        });
        ctx.setPacketHandled(true);
    }
}
