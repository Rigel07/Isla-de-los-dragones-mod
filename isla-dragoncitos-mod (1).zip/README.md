# La Isla de los Dragoncitos (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17).

## Qué añade
- **Islas flotantes** que aparecen en distintos lugares del mundo, casi siempre junto a un **río**: de la isla cae una **cascada** hasta el río y una **enredadera gigante** (raíces de manglar y musgo con lianas) sube desde el suelo hasta el borde. Se trepa por las lianas.
- Naturaleza preciosa: cerezos, robles, azaleas, flores, un **lago**, playa, lianas con bayas luminosas colgando por debajo, y una **plaza antigua** con pilares y arcos en ruinas y un **santuario** de piedra.
- **Dragoncitos** (rosa, verde, azul y rojo): no crecen, son cariñosos y vuelan con aleteos cortos.
  - Dales **carne** (vacuno, cerdo, cordero, pollo, conejo; cruda o cocinada) para domesticarlos (50 % de probabilidad por intento).
  - **Clic derecho** sobre uno tuyo: alterna entre *seguirte* y *quedarse quieto*. Con carne se cura.
- **Cofres** (en el santuario y junto a los pilares) con **escamas** de dragón verde, azul, roja y rosa y **manuscritos** con historias épicas de los antiguos dragones (son libros que se leen normal).
- **Estatua del Dragón** en el centro de cada isla:
  - Clic derecho en una estatua sin dueño: le pones **nombre** a la isla y pasa a ser **tuya**.
  - Solo tú y los jugadores a los que des permiso podéis **entrar, construir y destruir** (también protege contra explosiones y cubos de agua/lava). Quien no tenga permiso es devuelto al pie de la enredadera.
  - Desde la estatua puedes **teletransportarte a las otras islas** cuya estatua ya hayas usado.
  - El dueño gestiona los **permisos** (dar / quitar) desde el mismo menú de la estatua.

## Comandos
- `/isladragoncitos release` (operadores): libera la isla reclamada más cercana (a menos de 24 bloques).
- `/locate structure isladragoncitos:isla` para encontrar una isla.
- Los operadores (nivel 2) no tienen restricciones de protección.

## Ajustar la frecuencia
`src/main/resources/data/isladragoncitos/worldgen/structure_set/islas.json`: `spacing` (distancia media entre intentos, en chunks) y `separation`.
Dentro de `IslaStructure.java`, `NO_RIVER_CHANCE` controla cuántas islas aparecen lejos de un río.

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.
